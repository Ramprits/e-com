import React from "react";
import { getCart, CalculatedCart } from "../../utils";
import {
  Button,
  Form,
  FormGroup,
  Label,
  Input,
  Card,
  CardBody,
  Row,
  Col,
  Alert
} from "reactstrap";
import { Modal, ModalHeader, ModalBody, ModalFooter } from "reactstrap";
import {
  Elements,
  StripeProvider,
  CardElement,
  injectStripe
} from "react-stripe-elements";
import { ToastsStore } from "react-toasts";
// import Strapi from "strapi-sdk-javascript/build/main";
// const url = process.env.API_URL || "http://localhost:1337";
// const strapi = new Strapi(url);

class _CheckoutForm extends React.Component {
  state = {
    cartItems: [],
    shippingAddress: "",
    postalCode: "",
    city: "",
    confirmationEmail: "",
    orderProcessing: false,
    showModal: false
  };

  handleSubmitOrder = () => {};

  closeModal = () => this.setState({ showModal: false });
  handleChange = event => {
    this.setState({ [event.target.name]: event.target.value });
  };
  componentDidMount() {
    this.setState({ cartItems: getCart() });
  }

  handleConfirmationOrder = async event => {
    event.preventDefault();
    if (!this.isFormValid(this.state)) {
      ToastsStore.error("Please enter required fields");
    }
    this.setState({ showModal: true });
  };

  redirect = path => this.props.history.push(path);

  isFormValid = ({ shippingAddress, postalCode, city, confirmationEmail }) =>
    !shippingAddress || !postalCode || !city || !confirmationEmail;

  handleSubmit = async event => {
    event.preventDefault();
    if (!this.isFormValid(this.state)) {
      ToastsStore.error("Please enter required fields");
    }
  };

  redirect = path => this.props.history.push(path);

  isFormValid = ({ postalCode, shippingAddress, confirmationEmail, city }) =>
    !postalCode || !shippingAddress || !confirmationEmail || !city;

  render() {
    const { cartItems, showModal, orderProcessing } = this.state;
    return (
      <React.Fragment>
        {cartItems.length !== 0 ? (
          <React.Fragment>
            <Row>
              <Col className="col-md-10 col-xs-12  offset-md-1">
                <Card>
                  <CardBody>
                    <Form onSubmit={this.handleSubmit}>
                      <FormGroup row>
                        <label sm={4}>{cartItems.length} for items</label>
                        <Col sm={8} className="mr-auto">
                          {cartItems.map(item => (
                            <div key={item._id}>
                              <label>
                                {item.name} * {item.quantity} -
                                {item.price * item.quantity}
                              </label>
                              <br />
                              <label htmlFor="total">
                                Total: {CalculatedCart(cartItems)}
                              </label>
                            </div>
                          ))}
                        </Col>
                      </FormGroup>
                      <FormGroup row>
                        <Label for="shippingAddress" sm={2}>
                          Shipping Address
                        </Label>
                        <Col sm={10}>
                          <Input
                            type="text"
                            onChange={this.handleChange}
                            name="shippingAddress"
                            id="shippingAddress"
                            placeholder="Please enter your shipping Address"
                          />
                        </Col>
                      </FormGroup>

                      <FormGroup row>
                        <Label for="postalCode" sm={2}>
                          Postal Code
                        </Label>
                        <Col sm={10}>
                          <Input
                            type="text"
                            onChange={this.handleChange}
                            name="postalCode"
                            id="postalCode"
                            placeholder="Please enter your postal Code"
                          />
                        </Col>
                      </FormGroup>

                      <FormGroup row>
                        <Label for="city" sm={2}>
                          city
                        </Label>
                        <Col sm={10}>
                          <Input
                            type="city"
                            name="city"
                            onChange={this.handleChange}
                            id="city"
                            placeholder="Please enter city"
                          />
                        </Col>
                      </FormGroup>

                      <FormGroup row>
                        <Label for="confirmationEmail" sm={2}>
                          Confirmation Email
                        </Label>
                        <Col sm={10}>
                          <Input
                            type="confirmationEmail"
                            name="confirmationEmail"
                            onChange={this.handleChange}
                            id="confirmationEmail"
                            placeholder="Please enter confirmation Email"
                          />
                        </Col>
                      </FormGroup>
                      <FormGroup row>
                        <Label for="card" sm={2}>
                          Your card number
                        </Label>
                        <Col sm={10}>
                          <CardElement
                            className="form-control"
                            id="stripe__input"
                            onReady={input => input.focus()}
                          />
                        </Col>
                      </FormGroup>
                      <FormGroup check row>
                        <Col sm={{ size: 10, offset: 2 }}>
                          <Button
                            id="stripe__button"
                            onClick={this.handleConfirmationOrder}
                            color="primary"
                            size="sm"
                          >
                            Submit
                          </Button>
                        </Col>
                      </FormGroup>
                    </Form>
                  </CardBody>
                </Card>
              </Col>
            </Row>
          </React.Fragment>
        ) : (
          // if cart items are not available
          <Alert color="danger text-center">
            <img
              className="img w-25 h-25"
              src="http://localhost:1337/uploads/8d6a84d3374643059e008ff4c0aa940f.jpg"
              alt="thinking"
            />{" "}
            <br />
            Your cart items are empty!
          </Alert>
        )}
        {/* Confirmation modal */}
        {showModal && (
          <SummaryModal
            orderProcessing={orderProcessing}
            showModal={showModal}
            closeModal={this.closeModal}
            cartItems={cartItems}
            handleSubmitOrder={this.handleSubmitOrder}
          />
        )}
      </React.Fragment>
    );
  }
}

const SummaryModal = ({
  cartItems,
  showModal,
  handleSubmitOrder,
  orderProcessing,
  closeModal
}) => {
  return (
    <div>
      <Modal isOpen={showModal}>
        <ModalHeader>Summary your cart item</ModalHeader>
        <ModalBody>
          {cartItems.map(item => (
            <div key={item._id}>
              <label>
                {item.name} * {item.quantity} -{item.price * item.quantity}
              </label>
              <br />
              <label htmlFor="total">Total: {CalculatedCart(cartItems)}</label>
            </div>
          ))}
        </ModalBody>
        <ModalFooter>
          <Button color="primary" size="sm" onClick={handleSubmitOrder}>
            Submit
          </Button>
          <Button color="danger" size="sm" onClick={closeModal}>
            Cancel
          </Button>
        </ModalFooter>
      </Modal>
    </div>
  );
};
const CheckoutForm = injectStripe(_CheckoutForm);

const Checkout = () => (
  <StripeProvider apiKey="">
    <Elements>
      <CheckoutForm />
    </Elements>
  </StripeProvider>
);

export default Checkout;
